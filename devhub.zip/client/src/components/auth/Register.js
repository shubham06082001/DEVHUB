import React, { Fragment, useState } from "react";
import { Link, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { setAlert } from "../../actions/alert";
import { register } from "../../actions/auth";
import PropTypes from "prop-types";

// import axios from "axios";

const Register = ({ setAlert, register, isAuthenticated }) => {
  //field values
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    password2: "",
  });

  const { name, email, password, password2 } = formData;

  const onChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    if (password !== password2) {
      setAlert("passwords don't match!", "danger");
    } else {
      ////////////////
      // console.log("SUCCESS");
      register({ name, email, password });
    }
  };
  //redirect if registered
  if (isAuthenticated) {
    return <Redirect to="/dashboard"></Redirect>;
  }

  return (
    <Fragment>
      <section className="background-blue">
        <div className="row">
          <div className="col-lg-10 col-xl-9 mx-auto">
            <div className="card card-signin flex-row my-5">
              <div className="card-img-left d-none d-md-flex">
                
              </div>
              <div className="card-body">
                <h5
                  className="card-title text-center"
                  style={{
                    border: "2px solid green",
                    borderRadius: "12px",
                    margin: "20px",
                    padding: "10px",
                    width: "230px",
                  }}
                >
                  <i className="fas fa-user"></i> Register
                </h5>
                <form
                  className="form-signin"
                  // className="form"
                  action="/create-profile"
                  onSubmit={onSubmit}
                >
                  <div className="form-label-group">
                    <input
                      type="text"
                      id="inputUserame"
                      className="form-control"
                      placeholder="Enter your Name"
                      required
                      autofocus
                      name="name"
            value={name}
            onChange={onChange}
                    />
                    <label for="inputUserame">Name</label>
                  </div>

                  <div className="form-label-group">
                    <input
                      type="email"
                      id="inputEmail"
                      className="form-control"
                      placeholder="Email address"
                      required
                      name="email"
                      value={email}
            onChange={onChange}
                    />
                    <label for="inputEmail">Email address</label>
                    <small className="form-text">
                      This site uses Gravatar so if you want a profile image,
                      use a Gravatar email
                    </small>
                  </div>

                  <hr />

                  <div className="form-label-group">
                    <input
                      type="password"
                      id="inputPassword"
                      className="form-control"
                      placeholder="Password"
                      required
                      name="password"
                      minLength="6"
                      value={password}
            onChange={onChange}
                    />
                    <label for="inputPassword">Password</label>
                  </div>

                  <div className="form-label-group">
                    <input
                      type="password"
                      id="inputConfirmPassword"
                      className="form-control"
                      placeholder="Password"
                      required
                      name="password2"
                      minLength="6"
                      value={password2}
            onChange={onChange}
                    />
                    <label for="inputConfirmPassword">Confirm password</label>
                  </div>

                  <button
                    className="btn btn-lg btn-primary btn-block text-uppercase"
                    type="submit"
                    value="Register"
                  >
                    Register
                  </button>
                  <div>
                    <p className="d-block text-center mt-2 small" style={{fontSize: '20px'}}>
                      Already have an account?{" "}
                    </p>
                    <Link
                      className="d-block text-center mt-2 small"
                      to="/login" style={{fontSize: '25px'}}
                    >
                      Sign In
                    </Link>
                  </div>

                  <hr className="my-4" />
                  <button
                    className="btn btn-lg btn-google btn-block text-uppercase"
                    type="submit"
                  >
                    <i className="fab fa-google mr-2"></i> Sign up with Google
                  </button>
                  <button
                    className="btn btn-lg btn-facebook btn-block text-uppercase"
                    type="submit"
                  >
                    <i className="fab fa-facebook-f mr-2"></i> Sign up with
                    Facebook
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Fragment>
  );
};
Register.propTypes = {
  setAlert: PropTypes.func.isRequired,
  register: PropTypes.func.isRequired,
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

export default connect(mapStateToProps, { setAlert, register })(Register);
