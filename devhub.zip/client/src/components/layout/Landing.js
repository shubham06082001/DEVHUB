import React from "react";
import { Link, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";

const Landing = ({ isAuthenticated }) => {
  if (isAuthenticated) {
    return <Redirect to="/dashboard" />;
  }

  return (
    <section id="landing">
      <section id="hero">
        <div className="container">
          <div className="row">
            <div className="col-lg-7 pt-5 pt-lg-0 order-2 order-lg-1 d-flex align-items-center">
              <div data-aos="zoom-out">
                <h1>
                  Connect to <span>DEVELOPERS</span>
                </h1>
                <h2>
                  Create a developer profile/portfolio, share posts and get help
                  from other developers
                </h2>
                <div className="text-center text-lg-left">
                  <Link to="/register" className="btn-get-started scrollto">
                    Sign Up
                  </Link>
                  <Link to="/login" className="btn-get-started scrollto">
                    {" "}
                    Log In
                  </Link>
                </div>
              </div>
            </div>
            <div
              className="col-lg-5 order-1 order-lg-2 hero-img"
              data-aos="zoom-out"
              data-aos-delay="300"
            >
              <img
                src="./img/hero-img.png"
                className="img-fluid animated"
                alt=""
              />
            </div>
          </div>
        </div>

        <svg
          className="hero-waves"
          xmlns="http://www.w3.org/2000/svg"
          xmlnsXlink="http://www.w3.org/1999/xlink"
          viewBox="0 24 150 28 "
          preserveAspectRatio="none"
        >
          <defs>
            <path
              id="wave-path"
              d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"
            />
          </defs>
          <g className="wave1">
            <use
              xlinkHref="#wave-path"
              x="50"
              y="3"
              fill="rgba(255,255,255, .1)"
            />
          </g>
          <g className="wave2">
            <use
              xlinkHref="#wave-path"
              x="50"
              y="0"
              fill="rgba(255,255,255, .2)"
            />
          </g>
          <g className="wave3">
            <use xlinkHref="#wave-path" x="50" y="9" fill="#fff" />
          </g>
        </svg>
      </section>
      <main id="main">
        <section id="about" className="about">
          <div className="container-fluid">
            <div className="row">
              <div
                className="col-xl-5 col-lg-6 video-box d-flex justify-content-center align-items-stretch"
                data-aos="fade-right"
              ></div>

              <div
                className="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5"
                data-aos="fade-left"
              >
                <h3>Connect to your Favourite Developers in seconds</h3>
                <p>
                  This is a community where developers meet, share their views
                  and posts.
                </p>

                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="100"
                >
                  <div className="icon">
                    <i className="bx bx-fingerprint"></i>
                  </div>
                  <h4 className="title">
                    <a href="/register">Create your Profile</a>
                  </h4>
                  <p className="description">
                    A Developers community for you anytime anywhere.
                  </p>
                </div>

                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="200"
                >
                  <div className="icon">
                    <i className="bx bx-gift"></i>
                  </div>
                  <h4 className="title">
                    <a href="/register">Configure & Update your profile</a>
                  </h4>
                  <p className="description">
                    Fill out your details to help others find you.
                  </p>
                </div>

                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="300"
                >
                  <div className="icon">
                    <i className="bx bx-atom"></i>
                  </div>
                  <h4 className="title">
                    <a href="/register">
                      Get the latest Github Repos of your favourite Developers
                    </a>
                  </h4>
                  <p className="description">
                    Check out the latest Github Projects on which developers are
                    working!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section id="features" className="features">
          <div className="container">
            <div className="section-title" data-aos="fade-up">
              <h2>Features</h2>
              <p>Check The Features</p>
            </div>

            <div className="row" data-aos="fade-left">
              <div className="col-lg-3 col-md-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="50"
                >
                  <i className="ri-store-line" style={{ color: "#ffbb2c" }}></i>
                  <h3>
                    <a href="/dashboard">ABOUT</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4 mt-md-0">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="100"
                >
                  <i
                    className="ri-bar-chart-box-line"
                    style={{ color: "#5578ff" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">EDUCATION</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4 mt-md-0">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="150"
                >
                  <i
                    className="ri-calendar-todo-line"
                    style={{ color: "#e80368" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">SKILL SETS</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4 mt-lg-0">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="200"
                >
                  <i
                    className="ri-paint-brush-line"
                    style={{ color: "#e361ff" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">COMPANY</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="250"
                >
                  <i
                    className="ri-database-2-line"
                    style={{ color: "#47aeff" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">WEBSITE</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="300"
                >
                  <i
                    className="ri-gradienter-line"
                    style={{ color: "#ffa76e" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">SOCIAL NETWORKING LINKS</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="350"
                >
                  <i
                    className="ri-file-list-3-line"
                    style={{ color: "#11dbcf" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">DEVELOPERS PROFILE</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="400"
                >
                  <i
                    className="ri-price-tag-2-line"
                    style={{ color: "#4233ff" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">EXPERIENCE</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="450"
                >
                  <i
                    className="ri-anchor-line"
                    style={{ color: "#b2904f" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">DEGREE</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="500"
                >
                  <i className="ri-disc-line" style={{ color: "#b20969" }}></i>
                  <h3>
                    <a href="/dashboard">GIT PROFILE</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="550"
                >
                  <i
                    className="ri-base-station-line"
                    style={{ color: "#ff5828" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">GITHUB REPOSITORIES</a>
                  </h3>
                </div>
              </div>
              <div className="col-lg-3 col-md-4 mt-4">
                <div
                  className="icon-box"
                  data-aos="zoom-in"
                  data-aos-delay="600"
                >
                  <i
                    className="ri-fingerprint-line"
                    style={{ color: "#29cc61" }}
                  ></i>
                  <h3>
                    <a href="/dashboard">LIVE CHAT</a>
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section id="counts" className="counts">
          <div className="container">
            <div className="row" data-aos="fade-up">
              <div className="col-lg-3 col-md-6">
                <div className="count-box">
                  <i className="icofont-simple-smile"></i>
                  <span data-toggle="counter-up">232</span>
                  <p>Happy Users</p>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 mt-5 mt-md-0">
                <div className="count-box">
                  <i className="icofont-document-folder"></i>
                  <span data-toggle="counter-up">521</span>
                  <p>Github Repos</p>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 mt-5 mt-lg-0">
                <div className="count-box">
                  <i className="icofont-live-support"></i>
                  <span data-toggle="counter-up">LIVE</span>
                  <p>CHAT</p>
                </div>
              </div>

              <div className="col-lg-3 col-md-6 mt-5 mt-lg-0">
                <div className="count-box">
                  <i className="icofont-users-alt-5"></i>
                  <span data-toggle="counter-up">15</span>
                  <p>DEVELOPERS</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="details" className="details">
          <div className="container">
            <div className="row content">
              <div className="col-md-4" data-aos="fade-right">
                <img src="./img/details-1.png" className="img-fluid" alt="" />
              </div>
              <div className="col-md-8 pt-4" data-aos="fade-up">
                <h3 style={{ textAlign: "center" }}>
                  <ul
                    style={{
                      textDecoration: "underline",
                      textDecorationColor: "blue",
                    }}
                  >
                    DEVHUB
                  </ul>
                  is simply a hub created for developers to connect themselves.
                </h3>
                <p className="font-italic">
                  DEVHUB is a hub of qualified developers.
                </p>
                <ul>
                  <li>
                    <i className="icofont-check"></i> Check out the profile of
                    your favourite developer.
                  </li>
                  <li>
                    <i className="icofont-check"></i> Check out their Github
                    Repositories.
                  </li>
                  <li>
                    <i className="icofont-check"></i> Get help from other
                    developers through LIVE chat feature.
                  </li>
                  <li>
                    <i className="icofont-check"></i> Create your post and get
                    started.
                  </li>
                </ul>
                <p></p>
              </div>
            </div>

            <div className="row content">
              <div className="col-md-4 order-1 order-md-2" data-aos="fade-left">
                <img src="./img/details-4.png" className="img-fluid" alt="" />
              </div>
              <div
                className="col-md-8 pt-5 order-2 order-md-1"
                data-aos="fade-up"
              >
                <h3>
                  {" "}
                  <ul
                    style={{
                      textDecoration: "underline",
                      textDecorationColor: "blue",
                    }}
                  >
                    DEVCORD
                  </ul>
                </h3>
                <p className="font-italic">
                  A LIVE chat forum for the developers to reach their
                  favourites.
                </p>
                <p>
                  DEVCORD is a live chat app where user can talk to their
                  favourite developers.
                </p>
                <ul>
                  <li>
                    <i className="icofont-check"></i> Connect to your room.
                  </li>
                  <li>
                    <i className="icofont-check"></i> Start connecting to other
                    in just seconds.
                  </li>
                  <li>
                    <i className="icofont-check"></i> Start a conversation with
                    others related to your problem.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section id="testimonials" className="testimonials">
          <div className="container">
            <div
              className="owl-carousel testimonials-carousel"
              data-aos="zoom-in"
            >
              <div className="testimonial-item">
                <img
                  src="./img/testimonials/male.png"
                  className="testimonial-img"
                  alt=""
                />
                <h3>Matt Brandon</h3>
                <h4>DEVELOPER @ Microsoft</h4>
                <p>
                  <i className="bx bxs-quote-alt-left quote-icon-left"></i>
                  DEVHUB is just a creative idea to connect with each other.
                  <i className="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>

              <div className="testimonial-item">
                <img
                  src="./img/testimonials/female.png"
                  className="testimonial-img"
                  alt=""
                />
                <h3>Sara Johnson</h3>
                <h4>Entrepreneur</h4>
                <p>
                  <i className="bx bxs-quote-alt-left quote-icon-left"></i>
                  DEVCORD's LIVE chat feature is just awesome.
                  <i className="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="team" className="team">
          <div className="container">
            <div className="section-title" data-aos="fade-up">
              <h2>Team</h2>
              <p>Our Great Team</p>
            </div>

            <div className="row" data-aos="fade-left">
              <div className="col-lg-3 col-md-6">
                <div className="member" data-aos="zoom-in" data-aos-delay="100">
                  <div className="pic">
                    <img
                      src="./img/team/team-1.jpg"
                      className="img-fluid"
                      alt=""
                    />
                  </div>
                  <div className="member-info">
                    <h4>SHUBHAM KUMAR</h4>
                    <span>Chief Executive Officer</span>
                    <div className="social">
                      <a href="#shubham">
                        <i className="icofont-twitter icofont-3x"></i>
                      </a>
                      <a href="#shubham">
                        <i className="icofont-facebook icofont-3x"></i>
                      </a>
                      <a href="#shubham">
                        <i className="icofont-instagram icofont-3x"></i>
                      </a>
                      <a href="#shubham">
                        <i className="icofont-linkedin"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer id="footer">
        <div className="container">
          <div className="copyright">
            &copy; Copyright &nbsp; &nbsp;
            <strong>
              <span>
                <i className="fab fa-dochub fa-2x"></i>
                <i className="fab fa-internet-explorer fa-2x"></i>
                <i className="fab fa-vuejs fa-2x"></i>
                &nbsp;
                <i className="fas fa-heading fa-2x"></i>
                <i className="fas fa-underline fa-2x"></i>
                <i className="fab fa-btc fa-2x"></i>
                <i className="fab fa-hubspot fa-2x"></i>
              </span>
            </strong>{" "}
            &nbsp; &nbsp;
            <hr />
            <p>All Rights Reserved</p>
            <h3>
              <script>document.write(new Date().getUTCFullYear())</script>
            </h3>
            <a href="#back" className="back-to-top">
              <i className="icofont-simple-up"></i>
            </a>
          </div>
        </div>
      </footer>
    </section>
  );
};

Landing.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = (state) => ({
  isAuthenticated: state.auth.isAuthenticated,
});

export default connect(mapStateToProps)(Landing);
