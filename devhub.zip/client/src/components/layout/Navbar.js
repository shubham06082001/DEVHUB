// import React, { Fragment } from 'react';
// import { Link } from 'react-router-dom';
// import { connect } from 'react-redux';
// import PropTypes from 'prop-types';
// import { logout } from '../../actions/auth';

// const Navbar = ({ auth: { isAuthenticated, loading }, logout }) => {
//   const authLinks = (
//     <ul>
//       <li>
//         <Link to='/profiles'>Developers</Link>
//       </li>
//       <li>
//         <Link to='/posts'>Posts</Link>
//       </li>
//       <li>
//         <Link to='/dashboard'>
//           <i className='fas fa-user' />{' '}
//           <span className='hide-sm'>Dashboard</span>
//         </Link>
//       </li>
//       <li>
//         <a onClick={logout} href='#!'>
//           <i className='fas fa-sign-out-alt' />{' '}
//           <span className='hide-sm'>Logout</span>
//         </a>
//       </li>
//     </ul>
//   );

//   const guestLinks = (
//     <ul>
//       <li>
//         <Link to='/profiles'>Developers</Link>
//       </li>
//       <li>
//         <Link to='/register'>Register</Link>
//       </li>
//       <li>
//         <Link to='/login'>Login</Link>
//       </li>
//     </ul>
//   );

//   return (
//     <header id="header" className="fixed-top d-flex align-items-center">
//     <div className="container d-flex align-items-center">
//       <div className="logo mr-auto">
//         <div style={{ border: "2px solid white", margin: 5, padding: 3 }}>
//           <h1 className="text-light active">
//             <Link to="/">
//               <span>
//                 <i className="fab fa-dochub fa-2x"></i>
//                 <i className="fab fa-internet-explorer fa-2x"></i>
//                 <i className="fab fa-vuejs fa-2x"></i>
//                 &nbsp;
//                 <i className="fas fa-heading fa-2x"></i>
//                 <i className="fas fa-underline fa-2x"></i>
//                 <i className="fab fa-btc fa-2x"></i>
//                 <i className="fab fa-hubspot fa-2x"></i>
//               </span>
//             </Link>
//           </h1>
//         </div>
//       </div
//       ></div>
      
//     <nav className="nav-menu d-none d-lg-block navbar-expand-lg">
//       {!loading && (
//         <Fragment>{isAuthenticated ? authLinks : guestLinks}</Fragment>
//       )}
//     </nav>
//     </header>
//   );
// };

// Navbar.propTypes = {
//   logout: PropTypes.func.isRequired,
//   auth: PropTypes.object.isRequired
// };

// const mapStateToProps = state => ({
//   auth: state.auth
// });

// export default connect(
//   mapStateToProps,
//   { logout }
// )(Navbar);


import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { logout } from "../../actions/auth";

const Navbar = ({ auth: { isAuthenticated, loading }, logout }) => {
  const authLinks = (
    <ul>
      <li>
        <Link
          to="/profiles"
          className="nav-item nav-link btn-get-started scrollto"
        >
          {" "}
          Developers
        </Link>
      </li>
      <li>
        <Link
          to="/posts"
          className="nav-item nav-link btn-get-started scrollto"
        >
          Posts
        </Link>
      </li>
      <li>
        <Link
          to="/dashboard"
          className="nav-item nav-link btn-get-started scrollto"
        >
          <i className="nav-item nav-link fas fa-user" /> Dashboard
        </Link>
      </li>
      <li>
        <Link
          onClick={logout}
          to="#"
          className="nav-item nav-link btn-get-started scrollto"
        >
          <i className="fas fa-sign-out-alt"></i>{" "}
          <span className="hide-sm">Logout</span>
        </Link>
      </li>
    </ul>
  );

  const guestLinks = (
    <ul>
      <li>
        <Link to="#!" className="btn-get-started scrollto">
          {" "}
          Developers
        </Link>
      </li>
      <li>
        <Link to="/register" className="btn-get-started scrollto">
          Register
        </Link>
      </li>
      <li>
        <Link to="/login" className="btn-get-started scrollto">
          {" "}
          LogIn
        </Link>
      </li>
    </ul>
  );
  return (
    <header id="header" className="fixed-top d-flex align-items-center">
      <div className="container d-flex align-items-center">
        <div className="logo mr-auto">
          <div style={{ border: "2px solid white", margin: 5, padding: 3 }}>
            <h1 className="text-light active">
              <Link to="/">
                <span>
                  <i className="fab fa-dochub fa-2x"></i>
                  <i className="fab fa-internet-explorer fa-2x"></i>
                  <i className="fab fa-vuejs fa-2x"></i>
                  &nbsp;
                  <i className="fas fa-heading fa-2x"></i>
                  <i className="fas fa-underline fa-2x"></i>
                  <i className="fab fa-btc fa-2x"></i>
                  <i className="fab fa-hubspot fa-2x"></i>
                </span>
              </Link>
            </h1>
          </div>
        </div>

        <nav className="nav-menu d-none d-lg-block navbar-expand-lg">
          {!loading && (
            <Fragment>{isAuthenticated ? authLinks : guestLinks}</Fragment>
          )}
          {/* <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="/navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button> */}
        </nav>
      </div>
    </header>
  );
};

Navbar.propTypes = {
  logout: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  auth: state.auth,
});

export default connect(mapStateToProps, { logout })(Navbar);

